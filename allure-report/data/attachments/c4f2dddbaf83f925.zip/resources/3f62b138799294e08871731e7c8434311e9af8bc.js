
    ValidateEmail = function (email) {
        var pattern = new RegExp(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]+$/);
        return pattern.test(email);
    }
    function subscribeNow() {
        $('.subscription').removeClass('done');
		$("#spnSubMessage").html('');
        if (!ValidateEmail($("#txtsubEmail").val())) {
            $("#spnSubMessage").html("Please enter your valid email id");
            $("#txtsubEmail").css("border-color", "red");
            $("#txtsubEmail").focus();
            return false;
        }
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: "/Desktop/SubscribeNow",
            data: "{'email':'" + $("#txtsubEmail").val().trim() + "'}",
            success: function (response) {
                if (response == 1) {
                    $('.subscription').addClass('done');
                    $("#txtsubEmail").val('');
                    //$("#spnSubMessage").html("Subscribe successfully.");
                }
                else if (response == 2) {
                    $("#txtsubEmail").val('');
                    $("#spnSubMessage").html("You have already subscribed.");
                }
                else
                    $("#spnSubMessage").html("Please try again, after sometime.");
            },
            beforeSend: function (XMLHttpRequest) {

            },
            error: function (xmlHttpRequest, status, err) {

            }
        });
    }

// Attach once globally
document.addEventListener('click', function (e) {
  const clickedLi = e.target.closest('.leftfotmenu li');

  if (clickedLi && clickedLi.hasAttribute('onclick')) {
    const onclickValue = clickedLi.getAttribute('onclick');
    const match = onclickValue.match(/showSection\(['"](.+?)['"]\)/);
    if (match) {
      const sectionId = match[1];
      showSection(sectionId);

      // Toggle active class
      document.querySelectorAll('.leftfotmenu li').forEach(li => {
        li.classList.remove('ftnovact');
      });
      clickedLi.classList.add('ftnovact');
    }
  }
});

// Keep showSection global
function showSection(sectionId) {
  document.querySelectorAll('.rightfotmenu > div').forEach(el => {
    el.style.display = 'none';
  });

  const section = document.getElementById('section-' + sectionId);
  if (section) {
    section.style.display = 'flex'; // or block
  }
}


document.addEventListener('click', function (e) {

  /* ===== MOBILE FOOTER ACCORDION : OUR OFFERINGS ===== */
  const accMob = e.target.closest('.accordionmob');
  if (!accMob) return;

  accMob.classList.toggle('activeac');

  const panel = accMob.nextElementSibling;
  if (!panel) return;

  if (panel.style.maxHeight) {
    panel.style.maxHeight = null;
  } else {
    panel.style.maxHeight = panel.scrollHeight + 'px';
  }
});


