(function () {
  const toggleBtn = document.getElementById("contrastToggle");
  const icon = document.getElementById("contrastIcon");
  const body = document.body;

  //if (!toggleBtn || !icon) return;


  // ---------- Cookie Helpers ----------
  function setCookie(name, value, days) {
    let expires = "";
    if (days) {
      const d = new Date();
      d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
      expires = "; expires=" + d.toUTCString();
    }
    // shared across www + flight
    document.cookie = `${name}=${value || ""}${expires}; path=/; domain=.easemytrip.com; SameSite=None; Secure`;
  }

  function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(";");
    for (let c of ca) {
      c = c.trim();
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length);
    }
    return null;
  }

  // ---------- Contrast Functions ----------
  function applyContrast(mode) {
    if (mode === "bw") {
      body.classList.add("bw");
	  body.classList.remove("pro-member");
      icon.src = "https://images.emtcontent.com/nwhomfiles/brightness-icon-nw1.svg";
      icon.title = "Switch to normal mode";
    } else {
      body.classList.remove("bw");
      icon.src = "https://images.emtcontent.com/nwhomfiles/contrast-icon.svg";
      icon.title = "Switch to high contrast mode";
    }
  }

  function toggleContrast() {
    const isBW = body.classList.toggle("bw");
	if (isBW) body.classList.remove("pro-member");
    const mode = isBW ? "bw" : "normal";

    // Save in both localStorage & cookie
    localStorage.setItem("contrastMode", mode);
    setCookie("contrastMode", mode, 30);

    applyContrast(mode);
  }

  // ---------- Events ----------
  toggleBtn.addEventListener("click", function (e) {
    e.preventDefault();
    toggleContrast();
  });

  // ---------- Restore on Page Load ----------
window.addEventListener("DOMContentLoaded", function () {
  // Always prefer cookie (shared across subdomains)
  let savedMode = getCookie("contrastMode") || localStorage.getItem("contrastMode");

  if (savedMode) {
    localStorage.setItem("contrastMode", savedMode); // keep localStorage in sync
  }

  applyContrast(savedMode || "normal");
});

  // ---------- Sync across tabs on same subdomain ----------
  window.addEventListener("storage", function (e) {
    if (e.key === "contrastMode") {
      applyContrast(e.newValue);
      setCookie("contrastMode", e.newValue, 30); // keep cookie in sync
    }
  });
})();
