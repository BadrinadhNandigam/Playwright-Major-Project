(function () {
  const body = document.body;

  // ---------- Storage + Cookie Helpers ----------
  function setCookie(name, value, days) {
    let expires = "";
    if (days) {
      const d = new Date();
      d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
      expires = "; expires=" + d.toUTCString();
    }
    document.cookie = `${name}=${value || ""}${expires}; path=/; domain=.easemytrip.com; SameSite=None; Secure`;
  }

  function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(";");
    for (let c of ca) {
      c = c.trim();
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length);
    }
    return null;
  }

  // ---------- Icon updater ----------
  function updateIcon(mode) {
    const btn = document.getElementById("contrastToggle");
    if (!btn) return;

    const icon = btn.querySelector("img") || btn; // handle both <a><img> and <button>
    if (!icon) return;

    if (mode === "bw") {
      icon.src = "https://images.emtcontent.com/nwhomfiles/brightness-icon-nw1.svg";
      icon.title = "Switch to normal mode";
    } else {
      icon.src = "https://images.emtcontent.com/nwhomfiles/contrast-icon.svg";
      icon.title = "Switch to high contrast mode";
    }
  }

  // ---------- Contrast Functions ----------
  function applyContrast(mode) {
    if (mode === "bw") {
      body.classList.add("bw");
      body.classList.remove("pro-member");
    } else {
      body.classList.remove("bw");
    }
    updateIcon(mode);
  }

  function toggleContrast() {
    const isBW = body.classList.toggle("bw");
    if (isBW) body.classList.remove("pro-member");

    const mode = isBW ? "bw" : "normal";

    // save state
    localStorage.setItem("contrastMode", mode);
    setCookie("contrastMode", mode, 30);

    applyContrast(mode);
  }

  // ---------- Restore saved mode ----------
  function restoreMode() {
    let savedMode = localStorage.getItem("contrastMode") || getCookie("contrastMode") || "normal";
    applyContrast(savedMode);
  }

  // ---------- Attach event ----------
  function initContrastToggle() {
    const btn = document.getElementById("contrastToggle");
    if (btn && !btn.dataset.bound) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        toggleContrast();
      });
      btn.dataset.bound = "true"; // mark as initialized
      restoreMode(); // make sure icon matches body when header just loaded
    }
  }

  // ---------- Watch for header injection ----------
  const observer = new MutationObserver(() => {
    initContrastToggle();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // ---------- Sync across tabs ----------
  window.addEventListener("storage", function (e) {
    if (e.key === "contrastMode") {
      applyContrast(e.newValue);
      setCookie("contrastMode", e.newValue, 30);
    }
  });

  // ---------- First apply theme before header loads ----------
  restoreMode();
})();